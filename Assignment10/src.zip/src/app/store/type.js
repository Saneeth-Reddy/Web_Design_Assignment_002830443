export  const DAY_TYPE ="DAY_TYPE";
export  const TIME_WEATHER ="TIME_WEATHER";
export  const DAY_WEATHER ="DAY_WEATHER";
export  const CITY_CHANGE ="CITY_CHANGE";