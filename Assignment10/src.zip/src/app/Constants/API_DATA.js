export const GEO_URL = 'http://api.openweathermap.org/geo/1.0/'
export const API_KEY = '6029d0118562627ba7b80fc811d3fb27';

export const WEATHER_URL = 'http://api.openweathermap.org/data/2.5';
