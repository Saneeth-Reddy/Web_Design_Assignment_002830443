const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const app = express();
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost/mydatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Define User schema
const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    validate: {
      validator: (value) => /^[a-zA-Z\s]+$/.test(value),
      message: 'Invalid full name format',
    },
  },
  email: {
    type: String,
    required: true,
    unique: true,
    validate: {
      validator: (value) => /\S+@\S+\.\S+/.test(value),
      message: 'Invalid email address',
    },
  },
  password: {
    type: String,
    required: true,
    minlength: 8,
  },
});

// Hash password before saving user
userSchema.pre('save', async function (next) {
  const user = this;
  if (user.isModified('password')) {
    user.password = await bcrypt.hash(user.password, 10);
  }
  next();
});

const User = mongoose.model('User', userSchema);

// API Endpoint: Create User
app.post('/user/create', async (req, res) => {
  try {
    const { fullName, email, password } = req.body;
    const user = new User({ fullName, email, password });
    await user.save();
    res.status(201).send('User created successfully');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

// API Endpoint: Update User
app.put('/user/edit', async (req, res) => {
  try {
    const { fullName, password } = req.body;
    const user = await User.findOne({ email: req.body.email });

    if (!user) {
      throw new Error('User not found');
    }

    // Validate full name and password
    user.fullName = fullName;
    user.password = password;
    await user.save();

    res.status(200).send('User details updated successfully');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

// API Endpoint: Delete User
app.delete('/user/delete', async (req, res) => {
  try {
    const user = await User.findOneAndDelete({ email: req.body.email });

    if (!user) {
      throw new Error('User not found');
    }

    res.status(200).send('User deleted successfully');
  } catch (error) {
    res.status(400).send(error.message);
  }
});

// API Endpoint: Get All Users
app.get('/user/getAll', async (req, res) => {
  try {
    const users = await User.find({}, 'fullName email password');
    res.status(200).json(users);
  } catch (error) {
    res.status(400).send(error.message);
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});